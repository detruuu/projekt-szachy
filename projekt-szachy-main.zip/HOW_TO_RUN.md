# How to Run `projekt-szachy`

This repository contains two separate parts:

- `backend/` - Java Spring Boot REST API
- `frontend/` - static HTML/CSS/JavaScript frontend

The backend runs on port `8765` by default. The frontend is configured to call the backend at `http://localhost:8765/api`.

## 1. Required tools and versions

### Required

- **Java 17+**
- **Maven 3.8+**
- **MySQL 8+**
- **Git**

### Optional

- **Python 3** - only to serve the static frontend locally with `python -m http.server`
- **Node.js** - not required; the frontend has no `package.json` and no build step

## 2. Clone the repository

```bash
git clone https://github.com/detruuu/projekt-szachy.git
cd projekt-szachy
```

## 3. Database setup

### Database engine

Use **MySQL**.

### Recommended local schema

For local development, create a local schema named:

```text
chess_db
```

The repository's committed `application.properties` points to a remote MySQL database. Do not rely on the committed remote database credentials for local development. Override the datasource settings locally as shown below.

### Create local database and user

Log in to MySQL as an administrative user:

```bash
mysql -u root -p
```

Run:

```sql
CREATE DATABASE chess_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'chess_user'@'localhost' IDENTIFIED BY 'chess_pass';
GRANT ALL PRIVILEGES ON chess_db.* TO 'chess_user'@'localhost';
FLUSH PRIVILEGES;
```

### Initial schema/data import

No manual SQL import is required for the initial schema.

The backend contains a Flyway migration file:

```text
backend/src/main/resources/db/migration/V1__init.sql
```

Flyway runs automatically when the backend starts and creates the database tables. The migration creates schema objects only; it does not insert default data.

## 4. Backend configuration

The backend uses Spring Boot `application.properties` values. For local development, override the committed datasource settings with environment variables.

### Required local values

| Spring property | Environment variable | Local value |
|---|---|---|
| `server.port` | `SERVER_PORT` | `8765` |
| `spring.datasource.url` | `SPRING_DATASOURCE_URL` | `jdbc:mysql://localhost:3306/chess_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC` |
| `spring.datasource.username` | `SPRING_DATASOURCE_USERNAME` | `chess_user` |
| `spring.datasource.password` | `SPRING_DATASOURCE_PASSWORD` | `chess_pass` |
| `spring.jpa.hibernate.ddl-auto` | `SPRING_JPA_HIBERNATE_DDL_AUTO` | `update` |
| `spring.jpa.show-sql` | `SPRING_JPA_SHOW_SQL` | `true` |
| `spring.flyway.baseline-on-migrate` | `SPRING_FLYWAY_BASELINE_ON_MIGRATE` | `true` |

### Linux/macOS environment variables

Run these commands in the same terminal session before starting the backend:

```bash
export SERVER_PORT=8765
export SPRING_DATASOURCE_URL='jdbc:mysql://localhost:3306/chess_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
export SPRING_DATASOURCE_USERNAME='chess_user'
export SPRING_DATASOURCE_PASSWORD='chess_pass'
export SPRING_JPA_HIBERNATE_DDL_AUTO='update'
export SPRING_JPA_SHOW_SQL='true'
export SPRING_FLYWAY_BASELINE_ON_MIGRATE='true'
```

### Windows PowerShell environment variables

Run these commands in the same PowerShell session before starting the backend:

```powershell
$env:SERVER_PORT = "8765"
$env:SPRING_DATASOURCE_URL = "jdbc:mysql://localhost:3306/chess_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
$env:SPRING_DATASOURCE_USERNAME = "chess_user"
$env:SPRING_DATASOURCE_PASSWORD = "chess_pass"
$env:SPRING_JPA_HIBERNATE_DDL_AUTO = "update"
$env:SPRING_JPA_SHOW_SQL = "true"
$env:SPRING_FLYWAY_BASELINE_ON_MIGRATE = "true"
```

### Alternative: edit `application.properties`

Instead of environment variables, you can edit:

```text
backend/src/main/resources/application.properties
```

Use local values like this:

```properties
server.port=8765
spring.datasource.url=jdbc:mysql://localhost:3306/chess_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=chess_user
spring.datasource.password=chess_pass
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.flyway.baseline-on-migrate=true
```

Do not commit local passwords or machine-specific database settings.

## 5. Build and start the backend

From the repository root:

```bash
cd backend
mvn clean package
mvn spring-boot:run
```

The backend should start at:

```text
http://localhost:8765
```

The REST API base URL is:

```text
http://localhost:8765/api
```

### Run from the packaged JAR instead

After `mvn clean package`, you can also start the backend with:

```bash
cd backend
java -jar target/wap-initial-project-0.0.1-SNAPSHOT.jar
```

## 6. Build and start the frontend

The frontend is a static vanilla JavaScript application. There is no build step.

From the repository root:

```bash
cd frontend
python -m http.server 5500
```

On some systems the command is:

```bash
cd frontend
python3 -m http.server 5500
```

On Windows, you can also use:

```powershell
cd frontend
py -m http.server 5500
```

Open the frontend in a browser at:

```text
http://localhost:5500
```

The frontend calls the backend using the hardcoded API base URL in `frontend/js/api.js`:

```javascript
baseUrl: 'http://localhost:8765/api'
```

If you change the backend port, update this value accordingly.

## 7. Application URLs after startup

| Component | URL |
|---|---|
| Frontend | `http://localhost:5500` |
| Backend | `http://localhost:8765` |
| REST API base URL | `http://localhost:8765/api` |

## 8. Default login credentials

The backend uses HTTP Basic authentication for protected endpoints. The following in-memory users are configured:

| Username | Password | Role |
|---|---|---|
| `admin` | `admin123` | `ADMIN` |
| `arbiter` | `arbiter123` | `ARBITER` |
| `viewer` | `viewer123` | `VIEWER` |

Most `GET` endpoints are public. Creating/updating/deleting protected resources requires Basic Auth credentials.

## 9. Quick start summary

Terminal 1 - backend:

```bash
cd projekt-szachy/backend

export SERVER_PORT=8765
export SPRING_DATASOURCE_URL='jdbc:mysql://localhost:3306/chess_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
export SPRING_DATASOURCE_USERNAME='chess_user'
export SPRING_DATASOURCE_PASSWORD='chess_pass'
export SPRING_JPA_HIBERNATE_DDL_AUTO='update'
export SPRING_JPA_SHOW_SQL='true'
export SPRING_FLYWAY_BASELINE_ON_MIGRATE='true'

mvn spring-boot:run
```

Terminal 2 - frontend:

```bash
cd projekt-szachy/frontend
python -m http.server 5500
```

Then open:

```text
http://localhost:5500
```
